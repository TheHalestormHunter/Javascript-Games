//function name(caller, target, stageMod, actionChance, actionValue)
//actionValue = string for immunity or value to adjust by

var twoTurn;
var modSelfStat = 6;
var modTargStat = 6;
var statChange;
var currentSelfStage = 6;
var currentTargStage = 6;
var valueChange;
var statChanged = false;

var statStage = [0.25, 0.28, 0.33, 0.40, 0.50, 0.66, 1, 1.5, 2, 2.5, 3, 3.5, 4];


function modTextDisplay(changeValue){
	valueChange = changeValue;
}

function moveDelay(c, t, s, ch, v){
	
}
function modSpeed(c, t, s, ch, v){
	statChange = 3;
	if(v == 0) {
	modSelfStat = s + 6;
	pokemon[caller].statStage[statChange] = modSelfStat;
	pokemon[caller].stats[statChange] = pokemon[caller].stats[statChange] * statStage[modSelfStat]
	} else {
	modTargStat = s + 6;
	pokemon[target].statStage[statChange] = modTargStat;
	pokemon[target].stats[statChange] = pokemon[target].stats[statChange] * statStage[modSelfStat]	
	}
	modTextDisplay(s);
	statChanged = true;
}
function modAttack(c, t, s, ch, v){
	statChange = 1;
	if(v == 0){
	modSelfStat = s + 6;
	pokemon[caller].statStage[statChange] = modSelfStat;
	pokemon[caller].stats[statChange] = pokemon[caller].stats[statChange] * statStage[modSelfStat]
	} else {
	modTargStat = s + 6;
	pokemon[target].statStage[statChange] = modTargStat;
	pokemon[target].stats[statChange] = pokemon[target].stats[statChange] * statStage[modSelfStat]	
	}
	modTextDisplay(s);
	statChanged = true;
}
function modAccuracy(c, t, s, ch, v){
	
}
function modDefense(c, t, s, ch, v){
	statChange = 2;
	if(v == 0){
	modSelfStat = s + 6;
	pokemon[caller].statStage[statChange] = modSelfStat;
	pokemon[caller].stats[statChange] = pokemon[caller].stats[statChange] * statStage[modSelfStat]
	}
	if(v ==1){
	modTargStat = s + 6;
	pokemon[target].statStage[statChange] = modTargStat;
	pokemon[target].stats[statChange] = pokemon[target].stats[statChange] * statStage[modSelfStat]
	}
	modTextDisplay(s);
	statChanged = true;
	
}
function modSpecial(c, t, s, ch, v){
	statChange = 4;
	if(v == 0){
	modSelfStat = s + 6;
	pokemon[caller].statStage[statChange] = modSelfStat;
	pokemon[caller].stats[statChange] = pokemon[caller].stats[statChange] * statStage[modSelfStat]
	} else {
	modTargStat = s + 6;
	pokemon[target].statStage[statChange] = modTargStat;
	pokemon[target].stats[statChange] = pokemon[target].stats[statChange] * statStage[modSelfStat]	
	}
	modTextDisplay(s);
	statChanged = true;
}
function swapPokemon(c, t, s, ch, v){
	
}
function poison(c, t, s, ch, v){
console.log("I am called")
	
	//value 1 = okemon loses 1/16 Max HP every turn... 
	
	// value 2 = badly = 1/16++ every turn... cannot effect poison type pokemon
	
	//non volatile
	
}
function burn(c, t, s, ch, v){
	//pokemon loses 1/16 max hp every turn... cannot effect fire types
	
	//non volatile
	
}
function sleep(c, t, s, ch, v){
	
	//lasts for Math.floor(Math.random(c, t, s, ch, v)*7) turns
	
	//non volatile
	
}
function confuse(c, t, s, ch, v){
	
	//volatile
	// 50% chance to hurt itself
	// damage 40 power typeless without crit
	// wears off after 1-4 turns
	// recharge moves or not able to attack (paralyzed) do NOT count as turns
	// checks on multi turn attacks
	
	
}
function paralyze(c, t, s, ch, v){
	
	//25% chance to not use move
	//reduces speed by 25%
	
	//non volatile
	
}
function freeze(c, t, s, ch, v){
	
	//non volatile
	
}
function flinch(c, t, s, ch, v){
	// only happens if it hits before pokemon uses its own move
	// prevents from attacking
}
function instant(c, t, s, ch, v){
	// value : 1 horn drill breaks substitute, also will not affect if target speed > caller speed
	
}
function recoil(c, t, s, ch, v){
	// value = % damage
	// if value = 1 damage = 1/4 max caller HP
}
function recharge(c, t, s, ch, v){
	
}
function counter(c, t, s, ch, v){
	
}
function flatDmg(c, t, s, ch, v){
	
}
function rage(c, t, s, ch, v){
	
}
function digDetect(c, t, s, ch, v){
	
}
function teleport(c, t, s, ch, v){
	
}
function mirror(c, t, s, ch, v){
	
}
function protect(c, t, s, ch, v){
	
}
function bide(c, t, s, ch, v){
	
}
function randomMove(c, t, s, ch, v){
	
}
function selfDestruct(c, t, s, ch, v){
	
}
function swift(c, t, s, ch, v){
	
}
function skullBash(c, t, s, ch, v){
	
}
function recoverSleep(c, t, s, ch, v){
	
}
function skyAttack(c, t, s, ch, v){
	
}
function rest(c, t, s, ch, v){
	
}
function trifecta(c, t, s, ch, v){
	burn(c, t, s, ch, v);
	freeze(c, t, s, ch, v);
	paralyze(c, t, s, ch, v);
}
function substitute(c, t, s, ch, v){
	
}
function pin(c, t, s, ch, v){
	
}
function twin(c, t, s, ch, v){
	
}
function repeat(c, t, s, ch, v){
	
}
function gamble(c, t, s, ch, v){
	
}
function sumo(c, t, s, ch, v){
	
}
function gust(c, t, s, ch, v){
	
}
function trap(c, t, s, ch, v){
	
	//37.5% chance 2 turns, 37.5% chance 3 turns, 12.5% 4 turns 12.5 chance 5 turns
	//each attack does the same damage
	
	
}
function leech(c, t, s, ch, v){
	
	// cannot effect grass types
	//damages 1/16 max hp heals for same amount
	
}
function petalDance(c, t, s, ch, v){
	
}
function statLock(c, t, s, ch, v){
	
}
function reset(c, t, s, ch, v){
	//stagemod = 9 : reset all stats
	
}
function conversion(c, t, s, ch, v){
	
}
function growth(c, t, s, ch, v){
	
}
function splash(c, t, s, ch, v){
	
}
function blank(c, t, s, ch, v){
	
}
function copy(c, t, s, ch, v){
	localStorage.removeItem("savedMoves");
	localStorage.removeItem("saveGame");
	pokemon[caller] = pokemon[target]
	moveCalc(c, t, s, ch, v);
	pokeDisplay(c, t, s, ch, v);
}